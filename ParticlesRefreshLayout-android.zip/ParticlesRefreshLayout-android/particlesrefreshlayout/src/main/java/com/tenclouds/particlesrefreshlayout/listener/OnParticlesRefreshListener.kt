package com.tenclouds.particlesrefreshlayout.listener

interface OnParticleRefreshListener {

    fun onRefresh()
}