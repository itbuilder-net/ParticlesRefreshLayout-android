package com.tenclouds.particlesrefreshlayoutsample.adapter.item

data class Plant(val name: String,
                 val description: String,
                 val price: Float,
                 val imageRes: Int)